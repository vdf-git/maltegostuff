#!/usr/bin/env python3

from maltego_trx.entities import Person
from maltego_trx.transform import DiscoverableTransform
from maltego_trx.maltego import UIM_PARTIAL

class NameFromCSV(DiscoverableTransform):
    @classmethod
    def create_entities(cls, request, response):
        phone = request.Value

        try:
            names = cls.get_names(phonenr=phone)
            if names:
                for name in names:
                    response.addEntity(Person, name)
            else:
                response.addUIMessage("nul putte!")
        except IOError:
            response.addUIMessage("There is an error. You need to fix it", messageType=UIM_PARTIAL)

    @staticmethod
    def get_names(phonenr):
        matching_names = []
        with open('./data/test.csv') as infile:
            for ln in infile.readlines():
                phone, name = ln.split(",", 1)
                if phone.strip() == phonenr.strip():
                    matching_names.append(name.strip())
        return matching_names
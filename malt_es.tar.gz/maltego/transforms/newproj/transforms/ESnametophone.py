#!/usr/bin/env python3

from maltego_trx.entities import Person, PhoneNumber
from maltego_trx.transform import DiscoverableTransform
from maltego_trx.maltego import UIM_PARTIAL
from elasticsearch import Elasticsearch


class ESnametophone(DiscoverableTransform):
    @classmethod
    def create_entities(cls, request, response):
        name = request.Value

        try:
            phones = cls.get_phones(name=name)
            if phones:
                for phone in phones:
                    response.addEntity(PhoneNumber, phone)
            else:
                response.addUIMessage("nul putte!")
        except IOError:
            response.addUIMessage("There is an error. You need to fix it", messageType=UIM_PARTIAL)

    @staticmethod
    def get_phones(name):
        matching_phones = []
        es = Elasticsearch()
        res_from_es = es.search(index='phonebook', doc_type='phoneentry', body={"query": {"match": {"name": name}}})
        for h in res_from_es['hits']['hits']:
            matching_phones.append(h['_source']['phonenumber'])

        return matching_phones

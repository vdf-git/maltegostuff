#!/usr/bin/env python3

from maltego_trx.entities import Person
from maltego_trx.transform import DiscoverableTransform
from maltego_trx.maltego import UIM_PARTIAL
from elasticsearch import Elasticsearch


class ESphonetoname(DiscoverableTransform):
    @classmethod
    def create_entities(cls, request, response):
        phone = request.Value

        try:
            names = cls.get_names(phonenr=phone)
            if names:
                for name in names:
                    response.addEntity(Person, name)
            else:
                response.addUIMessage("nul putte!")
        except IOError:
            response.addUIMessage("There is an error. You need to fix it", messageType=UIM_PARTIAL)

    @staticmethod
    def get_names(phonenr):
        matching_names = []
        es = Elasticsearch()
        res_from_es = es.search(index='phonebook', doc_type='phoneentry', body={"query": {"match": {"phonenumber": ''.join(phonenr.strip().split(' '))}}})
        for h in res_from_es['hits']['hits']:
            matching_names.append(h['_source']['name'])

        return matching_names
